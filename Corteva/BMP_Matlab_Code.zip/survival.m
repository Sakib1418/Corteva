function newPopulation = survival(oldPopulation,fSurvival)
    newPopulation = fSurvival*oldPopulation;