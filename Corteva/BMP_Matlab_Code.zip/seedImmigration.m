function seedIn = seedImmigration(nGeno,varargin)
    seedIn = zeros(1,nGeno);